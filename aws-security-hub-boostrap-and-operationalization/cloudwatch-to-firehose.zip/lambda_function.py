import json
import gzip
import base64
import boto3
import os

def lambda_handler(event, context):
    kdf = boto3.client('firehose')
    firehoseStream = os.environ['FIREHOSE_TARGET']
    cloudwatchData = event['awslogs']['data']
    decodeCloudwatch = base64.b64decode(cloudwatchData)
    decompressCloudwatch = gzip.decompress(decodeCloudwatch)
    jsonPayload = json.loads(decompressCloudwatch)
    cloudtrailLogs = jsonPayload['logEvents']
    for log_event in cloudtrailLogs:
        logDump = json.dumps(log_event)
        try:
            response = kdf.put_record(DeliveryStreamName=firehoseStream,Record={'Data': logDump})
            print(response)
        except Exception as e:
            print(e)